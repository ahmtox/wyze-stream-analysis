"""
Wyzely - Python SDK for Wyze Cloud API
"""

from .client import WyzeClient

__version__ = "0.1.1"
__all__ = ["WyzeClient"] 