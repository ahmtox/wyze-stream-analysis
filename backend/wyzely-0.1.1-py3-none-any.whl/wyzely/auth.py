"""
Authentication module for Wyze API
"""

import json
import requests
from typing import Dict, Any


class Auth:
    """
    Authentication module for Wyze API.
    
    Handles login and token refresh operations.
    """
    
    def __init__(self, client):
        """
        Initialize the Auth module.
        
        Args:
            client: The WyzeClient instance.
        """
        self.client = client
        self.base_url = "https://auth-prod.api.wyze.com/api/user"
    
    def login(self, email: str, password: str) -> Dict[str, Any]:
        """
        Authenticate and retrieve access token.
        
        Args:
            email: The email address for the Wyze account.
            password: The password for the Wyze account (triple MD5 hashed).
            
        Returns:
            Dict containing the authentication response.
        """
        url = f"{self.base_url}/login"
        payload = json.dumps({"email": email, "password": password})
        headers = {
            'Content-Type': 'application/json',
            'Keyid': self.client.keyid,
            'Apikey': self.client.apikey
        }
        
        response = requests.post(url, headers=headers, data=payload)
        response.raise_for_status()  # Raise exception for HTTP errors
        
        return response.json()
    
    def refresh(self, refresh_token: str) -> Dict[str, Any]:
        """
        Refresh the access token using the refresh token.
        
        Args:
            refresh_token: The refresh token to use.
            
        Returns:
            Dict containing the refresh response.
        """
        url = f"{self.base_url}/refresh"
        payload = json.dumps({"refresh_token": refresh_token})
        headers = {
            'Content-Type': 'application/json',
            'Keyid': self.client.keyid,
            'Apikey': self.client.apikey
        }
        
        response = requests.post(url, headers=headers, data=payload)
        response.raise_for_status()  # Raise exception for HTTP errors
        
        return response.json() 