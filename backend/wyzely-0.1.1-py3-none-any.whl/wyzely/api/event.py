import json
import time
from typing import Dict, List, Optional, Union, Any

from ..api.base import BaseAPI


class EventAPI(BaseAPI):
    """API for interacting with Wyze event services."""

    def get_event_list(
        self,
        begin_time: Optional[int] = None,
        end_time: Optional[int] = None,
        page_size: int = 22,
        page_token: str = "",
        order_by: int = 2,
        event_type: int = 1,
        event_source_list: Optional[List[str]] = None,
        device_mac_list: Optional[List[str]] = None,
        event_tag_list: Optional[List[int]] = None,
    ) -> Dict:
        """
        Get a list of events from the Wyze event service.

        Args:
            begin_time: Start timestamp in seconds since epoch (defaults to 24 hours ago)
            end_time: End timestamp in milliseconds since epoch (defaults to current time)
            page_size: Number of events to return per page (default: 22)
            page_token: Token for pagination (default: empty string)
            order_by: Sort order (default: 2)
            event_type: Type of events to retrieve (default: 1)
            event_source_list: List of event sources to filter by (default: empty list)
            device_mac_list: List of device MAC addresses to filter by (default: empty list)
            event_tag_list: List of event tags to filter by (default: empty list)

        Returns:
            Dict containing event list data with the following structure:
            {
                "code": 1,  # 1 indicates success
                "message": "Success",
                "data": {
                    "event_list": [
                        {
                            "event_id": "...",
                            "device_mac": "...",
                            "device_model": "...",
                            "event_category": 0,
                            "event_value": "13",
                            "event_ts": 1741152495102,  # timestamp in milliseconds
                            "file_list": [...],
                            "event_resources": [...],
                            "event_params": {...},
                            "tag_list": [101, 104],
                            "read_state": 0
                        },
                        ...
                    ],
                    "total": 1,
                    "current": 1,
                    "hash": "1",
                    "version": 1
                }
            }
        """
        # Set default values
        if begin_time is None:
            begin_time = int(time.time()) - 86400  # 24 hours ago
        
        if end_time is None:
            end_time = int(time.time() * 1000)  # Current time in milliseconds
            
        if event_source_list is None:
            event_source_list = []
            
        if device_mac_list is None:
            device_mac_list = []
            
        if event_tag_list is None:
            event_tag_list = []

        # Current timestamp in milliseconds for the request
        current_ts = int(time.time() * 1000)

        # Prepare request payload
        payload = {
            "begin_time": begin_time,
            "end_time": end_time,
            "page_size": page_size,
            "page_token": page_token,
            "order_by": order_by,
            "event_type": event_type,
            "event_source_list": event_source_list,
            "device_mac_list": device_mac_list,
            "event_tag_list": event_tag_list,
            "ts": current_ts
        }

        # Make the API request
        response = self.client.make_api_request(
            url="https://event-service.wyzecam.com/app/get_event_list",
            method="POST",
            json_data=payload
        )

        return response
    
    def get_event_by_id(self, event_id: str) -> Dict:
        """
        Get a specific event by its ID.
        
        Args:
            event_id: The ID of the event to retrieve
            
        Returns:
            Dict containing the event data
            
        Note:
            This method currently has limitations due to the Wyze API's signature requirements.
            The Wyze API requires a specific signature for each request that cannot be easily generated.
            For direct access to event details, consider using the get_event_list method and filtering
            the results to find the specific event.
        """
        # Extract device_id from event_id (first 12 characters)
        device_id = event_id[:12] if len(event_id) >= 12 else ""
        
        # Current timestamp in milliseconds for nonce
        nonce = int(time.time() * 1000)
        
        try:
            # Make the API request
            response = self.client.make_api_request(
                url="https://app.wyzecam.com/app/v4/device/get_event",
                method="POST",
                json_data={
                    "nonce": nonce,
                    "device_id": device_id,
                    "event_id": event_id
                }
            )
            
            return response
        except Exception as e:
            # Check if the error is related to INVALID_SIGNATURE
            error_msg = str(e)
            if "INVALID_SIGNATURE" in error_msg or "403" in error_msg:
                return {
                    "code": 0,
                    "message": "Unable to retrieve event by ID due to signature requirements. "
                              "Please use get_event_list and filter the results to find the specific event."
                }
            
            # For other errors, return a generic error message
            return {
                "code": 0,
                "message": f"Error retrieving event by ID: {e}"
            }
    
    def parse_event_data(self, event: Dict) -> Dict:
        """
        Parse event data into a more usable format.

        Args:
            event: Raw event data from the API. Can be a regular event or an event with description.

        Returns:
            Dict containing parsed event data
        """
        # Check if this is an event with description (has vlm_insight field)
        if "vlm_insight" in event:
            # Extract VLM insight data
            vlm_insight = event.get("vlm_insight", {})
            
            parsed_event = {
                "id": event.get("event_id", ""),
                "device": {
                    "mac": event.get("device_mac", ""),
                    "model": event.get("device_model", "")
                },
                "timestamp": event.get("event_start_time", 0),
                "end_time": event.get("event_end_time", 0),
                "type": "insight",
                "description": vlm_insight.get("description_title", ""),
                "details": vlm_insight.get("video_description", ""),
                "score": vlm_insight.get("score", 0),
                "read_state": 0,  # Read status not provided in the response
                "resources": []
            }
            
            # Add thumbnail and video URLs if available
            thumbnail_url = self.get_thumbnail_url(event)
            if thumbnail_url:
                parsed_event["thumbnail_url"] = thumbnail_url
                
            video_url = self.get_video_url(event)
            if video_url:
                parsed_event["video_url"] = video_url
                
            return parsed_event
        
        # Regular event parsing
        parsed_event = {
            "id": event.get("event_id", ""),
            "device": {
                "mac": event.get("device_mac", ""),
                "model": event.get("device_model", "")
            },
            "timestamp": event.get("event_ts", 0),
            "type": event.get("event_value", ""),
            "category": event.get("event_category", 0),
            "tags": event.get("tag_list", []),
            "read_state": event.get("read_state", 0),
            "resources": []
        }
        
        # Extract resources (thumbnails, videos)
        for resource in event.get("event_resources", []):
            resource_type = resource.get("resource_type", "")
            resource_data = {
                "type": resource_type,
                "file_id": resource.get("file_id", ""),
                "url": resource.get("url", ""),
                "status": resource.get("status", 0)
            }
            
            # Add specific fields based on resource type
            if resource_type == "kvs":
                resource_data["begin_time"] = resource.get("begin_time", 0)
                resource_data["end_time"] = resource.get("end_time", 0)
                resource_data["is_playable"] = resource.get("is_playable", False)
            
            parsed_event["resources"].append(resource_data)
        
        return parsed_event
    
    def get_thumbnail_url(self, event: Dict) -> Optional[str]:
        """
        Extract the thumbnail URL from an event.
        
        Args:
            event: Event data from the API
            
        Returns:
            Thumbnail URL or None if not available
        """
        # Check if the event has file_list
        file_list = event.get("file_list", [])
        if not file_list:
            return None
        
        # Look for a thumbnail file
        for file in file_list:
            if file.get("type") == 1:  # Type 1 is thumbnail
                return file.get("url")
        
        return None
    
    def get_video_url(self, event: Dict) -> Optional[str]:
        """
        Extract the video URL from an event.
        
        Args:
            event: Event data from the API
            
        Returns:
            Video URL or None if not available
        """
        # Check if the event has file_list
        file_list = event.get("file_list", [])
        if not file_list:
            return None
        
        # Look for a video file
        for file in file_list:
            if file.get("type") == 2:  # Type 2 is video
                return file.get("url")
        
        return None
    
    def get_events_by_device(self, device_mac: str, **kwargs) -> Dict:
        """
        Get events for a specific device.
        
        Args:
            device_mac: MAC address of the device
            **kwargs: Additional parameters to pass to get_event_list
            
        Returns:
            Dict containing event list data
        """
        # Call get_event_list with the device_mac_list parameter
        return self.get_event_list(
            device_mac_list=[device_mac],
            **kwargs
        )
    
    def get_events_by_tag(self, tag: int, **kwargs) -> Dict:
        """
        Get events with a specific tag.
        
        Args:
            tag: Tag ID to filter by (e.g., 101 for motion)
            **kwargs: Additional parameters to pass to get_event_list
            
        Returns:
            Dict containing event list data
        """
        # Call get_event_list with the event_tag_list parameter
        return self.get_event_list(
            event_tag_list=[tag],
            **kwargs
        )
        
    # Event Insights API methods (merged from EventInsightAPI)
    
    def get_event_description(self, until_time: Optional[str] = None) -> Dict[str, Any]:
        """
        Get events with AI-generated descriptions from the Wyze Event Insights API.
        
        Args:
            until_time: The timestamp in milliseconds until which to retrieve events.
                        If not provided, current time will be used.
        
        Returns:
            Dict containing the response with described events.
        """
        # Use current time in milliseconds if until_time is not provided
        if until_time is None:
            until_time = str(int(time.time() * 1000))
        
        # Prepare request data
        json_data = {
            "until_time": until_time
        }
        
        try:
            # Make the API request
            response = self.client.make_api_request(
                url="https://event-insights-v3.wyzecam.com/external/v1/events/anomaly",
                method="POST",
                json_data=json_data
            )
            
            # Check if the response is a dictionary with insights
            if isinstance(response, dict) and "insights" in response:
                # Format the response to match the expected structure
                return {
                    "code": 1,
                    "data": {
                        "events": response.get("insights", [])
                    },
                    "message": "Success"
                }
            elif isinstance(response, dict) and "message" in response:
                # Return error message from the response
                return {
                    "code": 0,
                    "message": response.get("message", "Unknown error")
                }
            else:
                # Return a generic success message if the response doesn't match expected format
                return {
                    "code": 1,
                    "data": {
                        "events": []
                    },
                    "message": "No events found"
                }
        except Exception as e:
            # Return error message
            return {
                "code": 0,
                "message": f"Error retrieving event descriptions: {e}"
            } 