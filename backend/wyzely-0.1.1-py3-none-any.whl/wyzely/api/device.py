"""
Device API module for Wyze Cloud API
"""

import time
from typing import Dict, Any

from .base import BaseAPI


class DeviceAPI(BaseAPI):
    """
    Device API module for Wyze Cloud API.
    
    Handles device-related API endpoints.
    """
    
    def __init__(self, client):
        """
        Initialize the Device API.
        
        Args:
            client: The WyzeClient instance.
        """
        super().__init__(client)
        self.base_url = "https://event-insights-v3-beta.wyzecam.com/external/v1/devices"
    
    def get_profile(self, device_id: str) -> Dict[str, Any]:
        """
        Get the profile for a device.
        
        Args:
            device_id: The ID of the device.
            
        Returns:
            Dict containing the device profile.
        """
        url = f"{self.base_url}/{device_id}/profile"
        return self._make_request(method="GET", url=url)
    
    def update_profile(self, device_id: str, device_prompt: str) -> Dict[str, Any]:
        """
        Update the profile for a device.
        
        Args:
            device_id: The ID of the device.
            device_prompt: The prompt to set for the device.
            
        Returns:
            Dict containing the update response.
        """
        url = f"{self.base_url}/{device_id}/profile"
        data = {
            "nonce": str(int(time.time() * 1000)),
            "threshold_level": 1,  # Default threshold level
            "user_prompt": device_prompt
        }
        return self._make_request(method="PUT", url=url, data=data)
    
    def list_devices(self) -> Dict[str, Any]:
        """
        List all devices associated with the account.
        
        Returns:
            Dict containing the list of devices.
        """
        url = f"{self.base_url}"
        return self._make_request(method="GET", url=url)
        
    def get_device_info(self) -> Dict[str, Any]:
        """
        Get detailed information about all devices with user rights.
        
        This endpoint returns a list of all devices associated with the account,
        including the user's rights for each device (OWNER, SHARED, etc.).
        
        Returns:
            Dict containing the list of devices with user rights information.
            Example response:
            {
                "data": [
                    {
                        "user_id": "user_id_string",
                        "rights": "OWNER",
                        "device_mac": "device_mac_string"
                    },
                    ...
                ],
                "code": 1,
                "ts": timestamp,
                "message": "Success",
                "request_id": "request_id_string"
            }
        """
        # Based on the user's example, this is the correct endpoint
        url = "https://devicemgmt-service.wyze.com/device-management/api/user/device/relationship"
        
        # Only need Authorization header with access token
        headers = {
            "Authorization": self.client.access_token
        }
        
        # Use direct requests approach for this endpoint
        import requests
        response = requests.request("GET", url, headers=headers, data="")
        response.raise_for_status()
        return response.json() 