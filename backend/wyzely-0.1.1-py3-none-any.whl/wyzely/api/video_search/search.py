"""
Video Search API implementation for Wyze Cloud API.
"""

import time
import base64
import requests
import json
from typing import Dict, List, Any, Optional, Union

from ..base import BaseAPI


class VideoSearchAPI(BaseAPI):
    """
    Video Search API module for Wyze Cloud API.
    
    Handles video search-related API endpoints.
    """
    
    def __init__(self, client):
        """
        Initialize the Video Search API.
        
        Args:
            client: The WyzeClient instance.
        """
        super().__init__(client)
        self.base_url = "https://wyze-ai-video-search.wyzecam.com"
    
    def _make_request(
        self, 
        method: str, 
        url: str, 
        params: Optional[Dict[str, Any]] = None, 
        data: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None
    ) -> Dict[str, Any]:
        """
        Make a request to the Video Search API.
        
        This overrides the base _make_request method to use only the Authorization header
        without signature2 or other headers that are not needed for the Video Search API.
        
        Args:
            method: HTTP method (GET, POST, PUT, DELETE).
            url: The URL to make the request to.
            params: Query parameters for the request.
            data: Body data for the request.
            headers: Additional headers for the request.
            
        Returns:
            Dict containing the response.
        """
        if not self.client.access_token:
            raise ValueError("No access token available. Please login first.")
        
        # Prepare headers
        request_headers = {
            'Content-Type': 'application/json',
            'Authorization': self.client.access_token
        }
        
        # Add any additional headers
        if headers:
            request_headers.update(headers)
        
        # Make the request
        response = requests.request(
            method=method,
            url=url,
            params=params,
            json=data,
            headers=request_headers
        )
        
        # Handle errors
        response.raise_for_status()
        
        return response.json()
    
    def search_by_text(
        self,
        query: str,
        device_macs_to_include: Optional[List[str]] = None,
        event_tags_to_include: Optional[List[int]] = None,
        start_ts: Optional[int] = None,
        end_ts: Optional[int] = None,
        limit: int = 50
    ) -> Dict[str, Any]:
        """
        Search for events using a text query.
        
        Args:
            query: The text query to search for.
            device_macs_to_include: List of device MAC addresses to include in the search.
            event_tags_to_include: List of event tags to include in the search.
            start_ts: Start timestamp for the search range (milliseconds since epoch).
            end_ts: End timestamp for the search range (milliseconds since epoch).
            limit: Maximum number of results to return (default: 50).
            
        Returns:
            Dict containing the search results.
        """
        url = f"{self.base_url}/search"
        
        # If start_ts and end_ts are not provided, use the last 7 days
        if start_ts is None:
            start_ts = int((time.time() - 7 * 24 * 60 * 60) * 1000)
        if end_ts is None:
            end_ts = int(time.time() * 1000)
            
        data = {
            "query": query,
            "device_macs_to_include": device_macs_to_include or [],
            "event_tags_to_include": event_tags_to_include or [],
            "limit": limit
        }
        
        return self._make_request(method="POST", url=url, data=data)
    
    def search_by_image(
        self,
        image_path: str,
        device_macs_to_include: Optional[List[str]] = None,
        event_tags_to_include: Optional[List[int]] = None,
        start_ts: Optional[int] = None,
        end_ts: Optional[int] = None,
        limit: int = 50
    ) -> Dict[str, Any]:
        """
        Search for events using an image.
        
        Args:
            image_path: Path to the image file to use for the search.
            device_macs_to_include: List of device MAC addresses to include in the search.
            event_tags_to_include: List of event tags to include in the search.
            start_ts: Start timestamp for the search range (milliseconds since epoch).
            end_ts: End timestamp for the search range (milliseconds since epoch).
            limit: Maximum number of results to return (default: 50).
            
        Returns:
            Dict containing the search results.
        """
        url = f"{self.base_url}/search"
        
        # If start_ts and end_ts are not provided, use the last 7 days
        if start_ts is None:
            start_ts = int((time.time() - 7 * 24 * 60 * 60) * 1000)
        if end_ts is None:
            end_ts = int(time.time() * 1000)
        
        # Read and encode the image
        with open(image_path, "rb") as image_file:
            base64_image = base64.b64encode(image_file.read()).decode("utf-8")
        
        data = {
            "image": {
                "format": "jpeg",
                "base64_image": base64_image
            },
            "device_macs_to_include": device_macs_to_include or [],
            "event_tags_to_include": event_tags_to_include or [],
            "start_ts": start_ts,
            "end_ts": end_ts,
            "limit": limit,
            "nonce": str(int(time.time() * 1000))
        }
        
        return self._make_request(method="POST", url=url, data=data)
    
    def get_keywords(self) -> Dict[str, Any]:
        """
        Get the list of saved search keywords.
        
        Returns:
            Dict containing the list of keywords.
        """
        url = f"{self.base_url}/keyword"
        
        return self._make_request(method="GET", url=url)
    
    def create_keyword(self, keyword_id: int) -> Dict[str, Any]:
        """
        Create a new search keyword.
        
        Args:
            keyword_id: The ID of the keyword to create.
            
        Returns:
            Dict containing the created keyword.
        """
        url = f"{self.base_url}/keyword"
        data = {
            "keyword_id": keyword_id
        }
        
        return self._make_request(method="POST", url=url, data=data)
    
    def delete_keyword(self, keyword_id: int) -> Dict[str, Any]:
        """
        Delete a search keyword.
        
        Args:
            keyword_id: The ID of the keyword to delete.
            
        Returns:
            Dict containing the deletion response.
        """
        url = f"{self.base_url}/keyword/{keyword_id}"
        
        return self._make_request(method="DELETE", url=url)
    
    def get_keyword_recommendations(self, version: str = "v0") -> Dict[str, Any]:
        """
        Get keyword recommendations.
        
        Args:
            version: The API version to use (default: "v0").
            
        Returns:
            Dict containing the keyword recommendations.
        """
        url = f"{self.base_url}/recommendation"
        params = {
            "version": version
        }
        
        return self._make_request(method="GET", url=url, params=params)
    
    def get_keyword_auto_complete(self, query: str) -> Dict[str, Any]:
        """
        Get auto-complete suggestions for a keyword query.
        
        Args:
            query: The partial query to get suggestions for.
            
        Returns:
            Dict containing the auto-complete suggestions.
        """
        url = f"{self.base_url}/query_suggestion_auto_complete"
        params = {
            "query": query
        }
        
        return self._make_request(method="GET", url=url, params=params)
    
    def get_recommendation_window_state(self) -> Dict[str, Any]:
        """
        Get the state of the recommendation window.
        
        Returns:
            Dict containing the window state.
        """
        url = f"{self.base_url}/recommendation_window_state"
        
        return self._make_request(method="GET", url=url)
    
    def set_recommendation_window_state(self, show_window: bool) -> Dict[str, Any]:
        """
        Set the state of the recommendation window.
        
        Args:
            show_window: Whether to show the recommendation window.
            
        Returns:
            Dict containing the updated window state.
        """
        url = f"{self.base_url}/recommendation_window_state"
        data = {
            "show_window": show_window
        }
        
        return self._make_request(method="POST", url=url, data=data)
    
    def get_all_smart_alert_keywords(self) -> Dict[str, Any]:
        """
        Get all smart alert keywords.
        
        Returns:
            Dict containing the smart alert keywords.
        """
        url = f"{self.base_url}/recommendation/smart_alert/all"
        
        return self._make_request(method="GET", url=url)
    
    def get_trending_smart_alert_keywords(self) -> Dict[str, Any]:
        """
        Get trending smart alert keywords.
        
        Returns:
            Dict containing the trending smart alert keywords.
        """
        url = f"{self.base_url}/recommendation/smart_alert/trending"
        
        return self._make_request(method="GET", url=url)
    
    def get_custom_smart_alert_keywords(self) -> Dict[str, Any]:
        """
        Get custom smart alert keywords.
        
        Returns:
            Dict containing the custom smart alert keywords.
        """
        url = f"{self.base_url}/recommendation/smart_alert/custom"
        
        return self._make_request(method="GET", url=url)
    
    def search_smart_alert_keywords(self, query: str) -> Dict[str, Any]:
        """
        Search for smart alert keywords.
        
        Args:
            query: The search query.
            
        Returns:
            Dict containing the matching smart alert keywords.
        """
        url = f"{self.base_url}/recommendation/smart_alert/search"
        params = {
            "query": query
        }
        
        return self._make_request(method="GET", url=url, params=params)
    
    def get_search_history(self, count: int = 15) -> List[Dict[str, Any]]:
        """
        Get the search history.
        
        Args:
            count: The maximum number of history items to return (default: 15).
            
        Returns:
            List of search history items.
        """
        url = f"{self.base_url}/search_history"
        params = {
            "count": count
        }
        
        return self._make_request(method="GET", url=url, params=params)
    
    def delete_search_history(self, query_id: str) -> Dict[str, Any]:
        """
        Delete a search history item.
        
        Args:
            query_id: The ID of the search query to delete.
            
        Returns:
            Dict containing the deletion response.
        """
        url = f"{self.base_url}/search_history/{query_id}"
        
        return self._make_request(method="DELETE", url=url)
    
    def batch_delete_search_history(
        self, 
        query_ids: Optional[List[str]] = None, 
        delete_all: bool = False
    ) -> Dict[str, Any]:
        """
        Delete multiple search history items.
        
        Args:
            query_ids: List of query IDs to delete.
            delete_all: Whether to delete all search history.
            
        Returns:
            Dict containing the deletion response.
        """
        url = f"{self.base_url}/search_history/batch_delete"
        data = {
            "query_ids": query_ids or [],
            "delete_all": delete_all
        }
        
        return self._make_request(method="POST", url=url, data=data)
    
    def submit_feedback(
        self,
        is_search_result_accurate: bool,
        query: str,
        feedback_message: str = "",
        feedback_category_id: Optional[int] = None
    ) -> Dict[str, Any]:
        """
        Submit feedback about search results.
        
        Args:
            is_search_result_accurate: Whether the search results were accurate.
            query: The search query.
            feedback_message: Additional feedback message.
            feedback_category_id: The ID of the feedback category.
            
        Returns:
            Dict containing the feedback submission response.
        """
        url = f"{self.base_url}/feedback"
        data = {
            "is_search_result_accurate": is_search_result_accurate,
            "query": query,
            "feedback_message": feedback_message
        }
        
        if feedback_category_id is not None:
            data["feedback_category_id"] = feedback_category_id
        
        return self._make_request(method="POST", url=url, data=data)
    
    def get_feedback_categories(self) -> Dict[str, Any]:
        """
        Get the available feedback categories.
        
        Returns:
            Dict containing the feedback categories.
        """
        url = f"{self.base_url}/feedback_category"
        
        return self._make_request(method="GET", url=url)
    
    def register_video_search(self) -> Dict[str, Any]:
        """
        Register for video search.
        
        Returns:
            Dict containing the registration response.
        """
        url = f"{self.base_url}/onboarding/register"
        
        return self._make_request(method="POST", url=url)
    
    def get_onboarding_status(self) -> Dict[str, Any]:
        """
        Get the video search onboarding status.
        
        Returns:
            Dict containing the onboarding status.
        """
        url = f"{self.base_url}/onboarding/status"
        
        return self._make_request(method="GET", url=url)
    
    def get_onboarding_instruction_state(self) -> Dict[str, Any]:
        """
        Get the onboarding instruction state.
        
        Returns:
            Dict containing the instruction state.
        """
        url = f"{self.base_url}/onboarding/instruction_state"
        
        return self._make_request(method="GET", url=url)
    
    def set_onboarding_instruction_state(self, state: bool) -> Dict[str, Any]:
        """
        Set the onboarding instruction state.
        
        Args:
            state: The new instruction state.
            
        Returns:
            Dict containing the updated instruction state.
        """
        url = f"{self.base_url}/onboarding/instruction_state"
        data = {
            "state": state
        }
        
        return self._make_request(method="POST", url=url, data=data) 