"""
Video Search API module for Wyze Cloud API.
"""

from .search import VideoSearchAPI

__all__ = ['VideoSearchAPI'] 