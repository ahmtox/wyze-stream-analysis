"""
Base API module for Wyze Cloud API
"""

import json
import requests
from typing import Dict, Any, Optional

from ..utils import generate_signature2, generate_request_id


class BaseAPI:
    """
    Base API class for Wyze Cloud API.
    
    This class provides common functionality for all API modules.
    """
    
    def __init__(self, client):
        """
        Initialize the Base API.
        
        Args:
            client: The WyzeClient instance.
        """
        self.client = client
    
    def _make_request(
        self, 
        method: str, 
        url: str, 
        params: Optional[Dict[str, Any]] = None, 
        data: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None
    ) -> Dict[str, Any]:
        """
        Make a request to the Wyze API.
        
        Args:
            method: HTTP method (GET, POST, PUT, DELETE).
            url: The URL to make the request to.
            params: Query parameters for the request.
            data: Body data for the request.
            headers: Additional headers for the request.
            
        Returns:
            Dict containing the response.
        """
        if not self.client.access_token:
            raise ValueError("No access token available. Please login first.")
        
        # Generate request ID
        request_id = generate_request_id()
        
        # Prepare headers
        request_headers = {
            'Content-Type': 'application/json',
            'request-id': request_id,
            'access_token': self.client.access_token,
            'Authorization': f"Bearer {self.client.access_token}"
        }
        
        # Add signature2 based on content
        if data:
            encoded_content = json.dumps(data).encode()
        elif params:
            encoded_content = self._build_query_string(params).encode('utf-8')
        else:
            encoded_content = b''
        
        request_headers['signature2'] = generate_signature2(
            encoded_content=encoded_content,
            url=url,
            access_token=self.client.access_token
        )
        
        # Add any additional headers
        if headers:
            request_headers.update(headers)
        
        # Make the request
        response = requests.request(
            method=method,
            url=url,
            params=params,
            json=data,
            headers=request_headers
        )
        
        # Handle errors
        response.raise_for_status()
        
        return response.json()
    
    @staticmethod
    def _build_query_string(params: Dict[str, Any]) -> str:
        """
        Build a sorted query string from parameters.
        
        Args:
            params: Dictionary of query parameters.
            
        Returns:
            Sorted query string.
        """
        return "&".join(f"{k}={params[k]}" for k in sorted(params)) 