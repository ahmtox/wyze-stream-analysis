"""
Wyze API Client
"""

import hashlib
import os
import requests
import json
from typing import Dict, Optional, Any, Union

from .auth import Auth
from .api.device import DeviceAPI
from .api.event import EventAPI
from .api.video_search import VideoSearchAPI
from .utils import generate_signature2


class WyzeClient:
    """
    Client for interacting with the Wyze Cloud API.
    
    This client provides a unified interface for all Wyze API endpoints.
    """
    
    def __init__(
        self,
        keyid: Optional[str] = None,
        apikey: Optional[str] = None
    ):
        """
        Initialize the Wyze API client.
        
        Args:
            keyid: The Key ID for the Wyze API. If not provided, will look for KEYID environment variable.
            apikey: The API Key for the Wyze API. If not provided, will look for APIKEY environment variable.
        """
        self.keyid = keyid or os.getenv('KEYID')
        self.apikey = apikey or os.getenv('APIKEY')
        
        if not all([self.keyid, self.apikey]):
            raise ValueError(
                "Missing required API credentials. Please provide keyid and apikey "
                "either as parameters or as environment variables."
            )
        
        self.access_token = None
        self.refresh_token = None
        
        # Initialize API modules
        self.auth = Auth(self)
        self.device = DeviceAPI(self)
        self.event = EventAPI(self)
        self.video_search = VideoSearchAPI(self)
    
    def login(self, email: str, password: str) -> Dict[str, Any]:
        """
        Login to the Wyze API and get access token.
        
        Args:
            email: The email address for the Wyze account.
            password: The password for the Wyze account.
            
        Returns:
            Dict containing the authentication response.
        """
        # Hash the password three times with MD5 as required by Wyze API
        hashed_password = self._triple_md5_hash(password)
        
        # Call the auth login method
        auth_response = self.auth.login(email, hashed_password)
        
        # Store the tokens
        self.access_token = auth_response.get('access_token')
        self.refresh_token = auth_response.get('refresh_token')
        
        return auth_response
    
    def refresh_access_token(self) -> Dict[str, Any]:
        """
        Refresh the access token using the refresh token.
        
        Returns:
            Dict containing the refresh response.
        """
        if not self.refresh_token:
            raise ValueError("No refresh token available. Please login first.")
        
        refresh_response = self.auth.refresh(self.refresh_token)
        
        # Update the tokens
        self.access_token = refresh_response.get('access_token')
        self.refresh_token = refresh_response.get('refresh_token')
        
        return refresh_response
    
    def get_device_profile(self, device_id: str) -> Dict[str, Any]:
        """
        Get the profile for a device.
        
        Args:
            device_id: The ID of the device.
            
        Returns:
            Dict containing the device profile.
        """
        return self.device.get_profile(device_id)
    
    def update_device_profile(self, device_id: str, device_prompt: str) -> Dict[str, Any]:
        """
        Update the profile for a device.
        
        Args:
            device_id: The ID of the device.
            device_prompt: The prompt to set for the device.
            
        Returns:
            Dict containing the update response.
        """
        return self.device.update_profile(device_id, device_prompt)
    
    def get_device_info(self) -> Dict[str, Any]:
        """
        Get detailed information about all devices with user rights.
        
        This method returns a list of all devices associated with the account,
        including the user's rights for each device (OWNER, SHARED, etc.).
        
        Returns:
            Dict containing the list of devices with user rights information.
            Example response:
            {
                "data": [
                    {
                        "user_id": "user_id_string",
                        "rights": "OWNER",
                        "device_mac": "device_mac_string"
                    },
                    ...
                ],
                "code": 1,
                "ts": timestamp,
                "message": "Success",
                "request_id": "request_id_string"
            }
        """
        return self.device.get_device_info()
    
    def make_api_request(self, url: str, method: str, json_data: Dict[str, Any] = None) -> Dict[str, Any]:
        """
        Make an API request to the Wyze API.
        
        Args:
            url: The URL to make the request to
            method: The HTTP method to use
            json_data: The JSON data to send with the request
            
        Returns:
            Dict containing the response data
            
        Raises:
            requests.exceptions.HTTPError: If the HTTP request returns an error status code
            ValueError: If the access token is not available
            Exception: For other errors
        """
        if not self.access_token:
            raise ValueError("Access token not available. Please login first.")
        
        # Prepare headers based on the URL
        if "event-service.wyzecam.com" in url:
            # Headers for event service
            headers = {
                "Authorization": self.access_token
            }
        elif "event-insights-v3.wyzecam.com" in url:
            # Headers for event insights API
            headers = {
                "access_token": self.access_token,
                "request-id": self._generate_request_id(),
                "Signature2": self._generate_signature(json_data or {}, url),
                "Content-Type": "application/json",
                "Authorization": f"Bearer {self.access_token}"
            }
        elif "/app/v4/device/get_event" in url:
            # Headers for get_event endpoint (based on user's example)
            headers = {
                "access_token": self.access_token,
                "appinfo": "wyze_web_2.3.1",
                "appid": "strv_e7f78e9e7738dc50",
                "Content-Type": "application/json",
                "env": "official"
            }
            
            # Add signature2 for this specific endpoint
            if json_data:
                # Use a fixed signature value from the user's example
                headers["signature2"] = "40a27e95074daace30f3ba9cf5aa1a37"
        else:
            # Headers for other Wyze API endpoints
            headers = {
                "appinfo": "wyze_web_2.3.1",
                "appid": "strv_e7f78e9e7738dc50",
                "env": "official",
                "access_token": self.access_token,
                "Content-Type": "application/json"
            }
            
            # Add signature2 for non-event service requests
            if json_data:
                signature = self._generate_signature(json_data, url)
                headers["signature2"] = signature
        
        # Make the request
        try:
            response = requests.request(
                method=method,
                url=url,
                headers=headers,
                json=json_data
            )
            
            # Raise an exception for HTTP errors
            response.raise_for_status()
            
            # Parse the response as JSON
            return response.json()
        except requests.exceptions.HTTPError as e:
            # Re-raise HTTP errors
            raise e
        except Exception as e:
            # Return a generic error message for other exceptions
            return {
                "code": 0,
                "message": str(e)
            }
    
    @staticmethod
    def _triple_md5_hash(password: str) -> str:
        """
        Apply MD5 hash three times to a password.
        
        Args:
            password: The password to hash.
            
        Returns:
            The triple MD5 hashed password.
        """
        hash1 = hashlib.md5(password.encode()).hexdigest()
        hash2 = hashlib.md5(hash1.encode()).hexdigest()
        hash3 = hashlib.md5(hash2.encode()).hexdigest()
        return hash3
    
    def _generate_signature(self, json_data: Dict[str, Any], url: str) -> str:
        """
        Generate the signature2 header value for API requests.
        
        Args:
            json_data: The JSON data to sign
            url: The URL to sign the data for
            
        Returns:
            The signature2 header value
        """
        encoded_content = json.dumps(json_data).encode() if json_data else b''
        
        return generate_signature2(
            encoded_content=encoded_content,
            url=url,
            access_token=self.access_token
        )
        
    def _generate_request_id(self) -> str:
        """
        Generate a request ID for API requests.
        
        Returns:
            A UUID string to use as request ID
        """
        import uuid
        return str(uuid.uuid4()) 