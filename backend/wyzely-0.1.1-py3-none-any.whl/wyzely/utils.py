"""
Utility functions for Wyze API
"""

import hashlib
import hmac
import uuid
import json
import os
import base64
from typing import Dict, Any, Optional
from urllib.parse import urlparse


def generate_signature2(encoded_content: bytes, url: str, access_token: Optional[str] = None) -> str:
    """
    Generate signature2 for Wyze API authentication.
    
    Args:
        encoded_content: The encoded content to sign.
        url: The URL of the API endpoint to get the appropriate app_key.
        access_token: The access token from authentication. If None, only app_key is used.
        
    Returns:
        The generated signature2 string.
    """
    # Get the app_key from helper based on the URL
    netloc = urlparse(url).netloc
    helper_data = load_helper()
    app_key = helper_data.get(netloc)
    
    if not app_key:
        raise ValueError(f"No app_key found for URL: {url}")
    
    if access_token is None:
        app_security = hashlib.md5(app_key.encode()).hexdigest()
    else:
        app_security = hashlib.md5((access_token + app_key).encode()).hexdigest()
    
    signature2 = hmac.new(app_security.encode(), msg=encoded_content, digestmod='MD5').hexdigest()
    return signature2


def generate_request_id() -> str:
    """
    Generate a unique request ID.
    
    Returns:
        A UUID string to use as request ID.
    """
    return str(uuid.uuid4())


def build_query_string(params: Dict[str, Any]) -> str:
    """
    Build a sorted query string from parameters.
    
    Args:
        params: Dictionary of query parameters.
        
    Returns:
        Sorted query string.
    """
    return "&".join(f"{k}={params[k]}" for k in sorted(params)) 


def load_helper() -> Dict[str, str]:
    """
    Load helper.bin file into JSON.
    
    Returns:
        Dictionary loaded from helper.bin
    """
    current_dir = os.path.dirname(os.path.abspath(__file__))
    file_path = os.path.join(current_dir, 'helper.bin')
    
    try:
        # Open in binary mode instead of text mode
        with open(file_path, 'rb') as f:
            encoded_content = f.read()
            # Decode base64 content
            decoded_content = base64.b64decode(encoded_content).decode('utf-8')
            return json.loads(decoded_content)
    except FileNotFoundError:
        # If the file is not found, provide a helpful error message
        raise FileNotFoundError(
            f"Could not find helper.bin at {file_path}. "
            f"The file should be installed with the package. "
            f"Current directory: {current_dir}, "
            f"Files in directory: {os.listdir(current_dir) if os.path.exists(current_dir) else 'N/A'}"
        ) from None
    except Exception as e:
        # Provide more context for other errors
        raise Exception(f"Error loading helper.bin ({file_path}): {str(e)}") from e 