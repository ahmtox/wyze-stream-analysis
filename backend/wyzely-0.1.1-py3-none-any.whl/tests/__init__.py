"""
Tests for the Wyzely package
""" 