"""
Tests for the Video Search API module.
"""

import unittest
from unittest.mock import MagicMock, patch, mock_open
import base64
import time
from wyzely.api.video_search import VideoSearchAPI


class TestVideoSearchAPI(unittest.TestCase):
    """Test cases for the VideoSearchAPI class."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.mock_client = MagicMock()
        self.mock_client.access_token = "mock_access_token"
        self.api = VideoSearchAPI(self.mock_client)
        
        # Mock the _make_request method
        self.api._make_request = MagicMock()
        
        # Set up common test data
        self.test_nonce = str(int(time.time() * 1000))
        
    def test_search_by_text(self):
        """Test searching for events using a text query."""
        # Set up test data
        query = "person"
        device_macs = ["device1", "device2"]
        event_tags = [1, 2]
        start_ts = 1609459200000  # 2021-01-01 00:00:00
        end_ts = 1640995200000    # 2022-01-01 00:00:00
        limit = 10
        
        # Set up expected response
        expected_response = {
            "events": [
                {
                    "event_id": "event1",
                    "device_mac": "device1",
                    "event_ts": 1620000000000
                }
            ]
        }
        self.api._make_request.return_value = expected_response
        
        # Call the method
        response = self.api.search_by_text(
            query=query,
            device_macs_to_include=device_macs,
            event_tags_to_include=event_tags,
            start_ts=start_ts,
            end_ts=end_ts,
            limit=limit
        )
        
        # Check that _make_request was called with the correct arguments
        self.api._make_request.assert_called_once()
        args, kwargs = self.api._make_request.call_args
        
        self.assertEqual(kwargs["method"], "POST")
        self.assertEqual(kwargs["url"], "https://wyze-ai-video-search.wyzecam.com/search")
        self.assertEqual(kwargs["data"]["query"], query)
        self.assertEqual(kwargs["data"]["device_macs_to_include"], device_macs)
        self.assertEqual(kwargs["data"]["event_tags_to_include"], event_tags)
        self.assertEqual(kwargs["data"]["limit"], limit)
        
        # Check that the response is as expected
        self.assertEqual(response, expected_response)
    
    @patch("builtins.open", new_callable=mock_open, read_data=b"test_image_data")
    def test_search_by_image(self, mock_file):
        """Test searching for events using an image."""
        # Set up test data
        image_path = "test_image.jpg"
        device_macs = ["device1", "device2"]
        event_tags = [1, 2]
        start_ts = 1609459200000  # 2021-01-01 00:00:00
        end_ts = 1640995200000    # 2022-01-01 00:00:00
        limit = 10
        
        # Set up expected response
        expected_response = {
            "events": [
                {
                    "event_id": "event1",
                    "device_mac": "device1",
                    "event_ts": 1620000000000
                }
            ]
        }
        self.api._make_request.return_value = expected_response
        
        # Call the method
        response = self.api.search_by_image(
            image_path=image_path,
            device_macs_to_include=device_macs,
            event_tags_to_include=event_tags,
            start_ts=start_ts,
            end_ts=end_ts,
            limit=limit
        )
        
        # Check that _make_request was called with the correct arguments
        self.api._make_request.assert_called_once()
        args, kwargs = self.api._make_request.call_args
        
        self.assertEqual(kwargs["method"], "POST")
        self.assertEqual(kwargs["url"], "https://wyze-ai-video-search.wyzecam.com/search")
        self.assertEqual(kwargs["data"]["device_macs_to_include"], device_macs)
        self.assertEqual(kwargs["data"]["event_tags_to_include"], event_tags)
        self.assertEqual(kwargs["data"]["limit"], limit)
        
        # Check that the image was read and encoded correctly
        mock_file.assert_called_once_with(image_path, "rb")
        
        # Check that the response is as expected
        self.assertEqual(response, expected_response)
    
    def test_get_keywords(self):
        """Test getting the list of saved search keywords."""
        # Set up expected response
        expected_response = {
            "keywords": [
                {
                    "keyword_id": 1,
                    "keyword": "person",
                    "create_ts": 1620000000000
                }
            ]
        }
        self.api._make_request.return_value = expected_response
        
        # Call the method
        response = self.api.get_keywords()
        
        # Check that _make_request was called with the correct arguments
        self.api._make_request.assert_called_once()
        args, kwargs = self.api._make_request.call_args
        
        self.assertEqual(kwargs["method"], "GET")
        self.assertEqual(kwargs["url"], "https://wyze-ai-video-search.wyzecam.com/keyword")
        
        # Check that the response is as expected
        self.assertEqual(response, expected_response)
    
    def test_create_keyword(self):
        """Test creating a new search keyword."""
        # Set up test data
        keyword_id = 1
        
        # Set up expected response
        expected_response = {
            "keyword_id": keyword_id,
            "keyword": "person",
            "create_ts": 1620000000000
        }
        self.api._make_request.return_value = expected_response
        
        # Call the method
        response = self.api.create_keyword(keyword_id=keyword_id)
        
        # Check that _make_request was called with the correct arguments
        self.api._make_request.assert_called_once()
        args, kwargs = self.api._make_request.call_args
        
        self.assertEqual(kwargs["method"], "POST")
        self.assertEqual(kwargs["url"], "https://wyze-ai-video-search.wyzecam.com/keyword")
        self.assertEqual(kwargs["data"]["keyword_id"], keyword_id)
        
        # Check that the response is as expected
        self.assertEqual(response, expected_response)
    
    def test_delete_keyword(self):
        """Test deleting a search keyword."""
        # Set up test data
        keyword_id = 1
        
        # Set up expected response
        expected_response = {
            "msg": "deleted"
        }
        self.api._make_request.return_value = expected_response
        
        # Call the method
        response = self.api.delete_keyword(keyword_id=keyword_id)
        
        # Check that _make_request was called with the correct arguments
        self.api._make_request.assert_called_once()
        args, kwargs = self.api._make_request.call_args
        
        self.assertEqual(kwargs["method"], "DELETE")
        self.assertEqual(kwargs["url"], f"https://wyze-ai-video-search.wyzecam.com/keyword/{keyword_id}")
        
        # Check that the response is as expected
        self.assertEqual(response, expected_response)
    
    def test_get_keyword_recommendations(self):
        """Test getting keyword recommendations."""
        # Set up test data
        version = "v1"
        
        # Set up expected response
        expected_response = {
            "keywords": ["person", "car", "package"]
        }
        self.api._make_request.return_value = expected_response
        
        # Call the method
        response = self.api.get_keyword_recommendations(version=version)
        
        # Check that _make_request was called with the correct arguments
        self.api._make_request.assert_called_once()
        args, kwargs = self.api._make_request.call_args
        
        self.assertEqual(kwargs["method"], "GET")
        self.assertEqual(kwargs["url"], "https://wyze-ai-video-search.wyzecam.com/recommendation")
        self.assertEqual(kwargs["params"]["version"], version)
        
        # Check that the response is as expected
        self.assertEqual(response, expected_response)
    
    def test_get_search_history(self):
        """Test getting the search history."""
        # Set up test data
        count = 5
        
        # Set up expected response
        expected_response = [
            {
                "query": "person",
                "query_id": "query1",
                "ts": 1620000000000
            }
        ]
        self.api._make_request.return_value = expected_response
        
        # Call the method
        response = self.api.get_search_history(count=count)
        
        # Check that _make_request was called with the correct arguments
        self.api._make_request.assert_called_once()
        args, kwargs = self.api._make_request.call_args
        
        self.assertEqual(kwargs["method"], "GET")
        self.assertEqual(kwargs["url"], "https://wyze-ai-video-search.wyzecam.com/search_history")
        self.assertEqual(kwargs["params"]["count"], count)
        
        # Check that the response is as expected
        self.assertEqual(response, expected_response)
    
    def test_submit_feedback(self):
        """Test submitting feedback about search results."""
        # Set up test data
        is_search_result_accurate = True
        query = "person"
        feedback_message = "Great results!"
        feedback_category_id = 1
        
        # Set up expected response
        expected_response = {
            "msg": "success"
        }
        self.api._make_request.return_value = expected_response
        
        # Call the method
        response = self.api.submit_feedback(
            is_search_result_accurate=is_search_result_accurate,
            query=query,
            feedback_message=feedback_message,
            feedback_category_id=feedback_category_id
        )
        
        # Check that _make_request was called with the correct arguments
        self.api._make_request.assert_called_once()
        args, kwargs = self.api._make_request.call_args
        
        self.assertEqual(kwargs["method"], "POST")
        self.assertEqual(kwargs["url"], "https://wyze-ai-video-search.wyzecam.com/feedback")
        self.assertEqual(kwargs["data"]["is_search_result_accurate"], is_search_result_accurate)
        self.assertEqual(kwargs["data"]["query"], query)
        self.assertEqual(kwargs["data"]["feedback_message"], feedback_message)
        self.assertEqual(kwargs["data"]["feedback_category_id"], feedback_category_id)
        
        # Check that the response is as expected
        self.assertEqual(response, expected_response)


if __name__ == "__main__":
    unittest.main() 