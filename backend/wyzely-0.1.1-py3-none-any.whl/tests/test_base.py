"""
Tests for the BaseAPI class
"""

import unittest
from unittest.mock import patch, MagicMock

from wyzely.api.base import BaseAPI


class TestBaseAPI(unittest.TestCase):
    """Test cases for the BaseAPI class."""
    
    def setUp(self):
        """Set up test fixtures."""
        # Create a mock client
        self.mock_client = MagicMock()
        self.mock_client.access_token = 'test_access_token'
        self.mock_client.keyid = 'test_keyid'
        self.mock_client.apikey = 'test_apikey'
        
        # Create a BaseAPI instance
        self.base_api = BaseAPI(self.mock_client)
    
    def test_init(self):
        """Test initialization."""
        self.assertEqual(self.base_api.client, self.mock_client)
    
    @patch('wyzely.api.base.requests.request')
    @patch('wyzely.api.base.generate_request_id')
    @patch('wyzely.api.base.generate_signature2')
    def test_make_request_with_data(self, mock_generate_signature2, mock_generate_request_id, mock_request):
        """Test the _make_request method with data."""
        # Mock the dependencies
        mock_generate_request_id.return_value = 'test_request_id'
        mock_generate_signature2.return_value = 'test_signature2'
        
        # Mock the response
        mock_response = MagicMock()
        mock_response.json.return_value = {'status': 'success'}
        mock_request.return_value = mock_response
        
        # Call the _make_request method
        data = {'key': 'value'}
        response = self.base_api._make_request(
            method="POST",
            url="https://example.com/api",
            data=data
        )
        
        # Check that the dependencies were called with the correct arguments
        mock_generate_request_id.assert_called_once()
        mock_generate_signature2.assert_called_once()
        args, kwargs = mock_generate_signature2.call_args
        self.assertEqual(kwargs['url'], "https://example.com/api")
        self.assertEqual(kwargs['access_token'], 'test_access_token')
        
        # Check that the request was made with the correct arguments
        mock_request.assert_called_once()
        args, kwargs = mock_request.call_args
        self.assertEqual(kwargs['method'], "POST")
        self.assertEqual(kwargs['url'], "https://example.com/api")
        self.assertEqual(kwargs['json'], data)
        self.assertEqual(kwargs['headers']['request-id'], 'test_request_id')
        self.assertEqual(kwargs['headers']['signature2'], 'test_signature2')
        
        # Check that the response was returned
        self.assertEqual(response, {'status': 'success'})
    
    @patch('wyzely.api.base.requests.request')
    @patch('wyzely.api.base.generate_request_id')
    @patch('wyzely.api.base.generate_signature2')
    def test_make_request_with_params(self, mock_generate_signature2, mock_generate_request_id, mock_request):
        """Test the _make_request method with params."""
        # Mock the dependencies
        mock_generate_request_id.return_value = 'test_request_id'
        mock_generate_signature2.return_value = 'test_signature2'
        
        # Mock the response
        mock_response = MagicMock()
        mock_response.json.return_value = {'status': 'success'}
        mock_request.return_value = mock_response
        
        # Call the _make_request method
        params = {'key': 'value'}
        response = self.base_api._make_request(
            method="GET",
            url="https://example.com/api",
            params=params
        )
        
        # Check that the dependencies were called with the correct arguments
        mock_generate_request_id.assert_called_once()
        mock_generate_signature2.assert_called_once()
        
        # Check that the request was made with the correct arguments
        mock_request.assert_called_once()
        args, kwargs = mock_request.call_args
        self.assertEqual(kwargs['method'], "GET")
        self.assertEqual(kwargs['url'], "https://example.com/api")
        self.assertEqual(kwargs['params'], params)
        
        # Check that the response was returned
        self.assertEqual(response, {'status': 'success'})


if __name__ == '__main__':
    unittest.main() 