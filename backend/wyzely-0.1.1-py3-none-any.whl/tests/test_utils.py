"""
Tests for utility functions
"""

import unittest
from unittest.mock import patch
import hashlib
import hmac
import uuid

from wyzely.utils import generate_signature2, generate_request_id, build_query_string


class TestUtils(unittest.TestCase):
    """Test utility functions."""
    
    @patch('wyzely.utils.load_helper')
    def test_generate_signature2_without_access_token(self, mock_load_helper):
        """Test generate_signature2 without access token."""
        # Mock the helper data
        mock_load_helper.return_value = {
            "example.com": "test_app_key"
        }
        
        # Test data
        encoded_content = b'test_content'
        url = "https://example.com/api"
        
        # Calculate expected signature
        app_security = hashlib.md5("test_app_key".encode()).hexdigest()
        expected_signature = hmac.new(app_security.encode(), msg=encoded_content, digestmod='MD5').hexdigest()
        
        # Call the function
        signature = generate_signature2(encoded_content, url)
        
        # Verify the signature
        self.assertEqual(len(signature), 32)
        self.assertTrue(all(c in '0123456789abcdef' for c in signature))
    
    @patch('wyzely.utils.load_helper')
    def test_generate_signature2_with_access_token(self, mock_load_helper):
        """Test generate_signature2 with access token."""
        # Mock the helper data
        mock_load_helper.return_value = {
            "example.com": "test_app_key"
        }
        
        # Test data
        encoded_content = b'test_content'
        url = "https://example.com/api"
        access_token = "test_access_token"
        
        # Calculate expected signature
        app_security = hashlib.md5((access_token + "test_app_key").encode()).hexdigest()
        expected_signature = hmac.new(app_security.encode(), msg=encoded_content, digestmod='MD5').hexdigest()
        
        # Call the function
        signature = generate_signature2(encoded_content, url, access_token)
        
        # Verify the signature
        self.assertEqual(len(signature), 32)
        self.assertTrue(all(c in '0123456789abcdef' for c in signature))
    
    def test_generate_request_id(self):
        """Test generate_request_id."""
        # Generate request ID
        request_id = generate_request_id()
        
        # Verify request ID is a valid UUID
        uuid.UUID(request_id)
    
    def test_build_query_string(self):
        """Test build_query_string."""
        # Test with multiple parameters
        params = {'b': 2, 'a': 1, 'c': 3}
        query_string = build_query_string(params)
        
        # Verify parameters are sorted by key
        self.assertEqual(query_string, 'a=1&b=2&c=3')


if __name__ == '__main__':
    unittest.main() 