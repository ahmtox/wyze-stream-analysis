"""
Tests for the Device API module
"""

import unittest
from unittest.mock import patch, MagicMock

from wyzely.api.device import DeviceAPI


class TestDeviceAPI(unittest.TestCase):
    """Test cases for the Device API module."""
    
    def setUp(self):
        """Set up test fixtures."""
        # Create a mock client
        self.mock_client = MagicMock()
        self.mock_client.app_key = 'test_app_key'
        self.mock_client.access_token = 'test_access_token'
        
        # Create device API instance
        self.device_api = DeviceAPI(self.mock_client)
    
    @patch('wyzely.api.base.BaseAPI._make_request')
    def test_get_profile(self, mock_make_request):
        """Test the get_profile method."""
        # Mock the response
        mock_response = {'device_id': 'test_device_id', 'profile': 'test_profile'}
        mock_make_request.return_value = mock_response
        
        # Call the get_profile method
        response = self.device_api.get_profile('test_device_id')
        
        # Check that _make_request was called with the correct arguments
        mock_make_request.assert_called_once_with(
            method="GET",
            url="https://event-insights-v3-beta.wyzecam.com/external/v1/devices/test_device_id/profile"
        )
        
        # Check that the response was returned
        self.assertEqual(response, mock_response)
    
    @patch('wyzely.api.base.BaseAPI._make_request')
    @patch('time.time')
    def test_update_profile(self, mock_time, mock_make_request):
        """Test the update_profile method."""
        # Mock the time and response
        mock_time.return_value = 1234567890.123
        mock_response = {'device_id': 'test_device_id', 'status': 'success'}
        mock_make_request.return_value = mock_response
        
        # Call the update_profile method
        response = self.device_api.update_profile('test_device_id', 'test_prompt')
        
        # Check that _make_request was called with the correct arguments
        mock_make_request.assert_called_once()
        args, kwargs = mock_make_request.call_args
        self.assertEqual(kwargs['method'], "PUT")
        self.assertEqual(kwargs['url'], "https://event-insights-v3-beta.wyzecam.com/external/v1/devices/test_device_id/profile")
        self.assertEqual(kwargs['data']['user_prompt'], 'test_prompt')
        self.assertEqual(kwargs['data']['threshold_level'], 1)
        
        # Check that the response was returned
        self.assertEqual(response, mock_response)
    
    @patch('wyzely.api.base.BaseAPI._make_request')
    def test_list_devices(self, mock_make_request):
        """Test the list_devices method."""
        # Mock the response
        mock_response = {'devices': [{'device_id': 'test_device_id'}]}
        mock_make_request.return_value = mock_response
        
        # Call the list_devices method
        response = self.device_api.list_devices()
        
        # Check that _make_request was called with the correct arguments
        mock_make_request.assert_called_once_with(
            method="GET",
            url="https://event-insights-v3-beta.wyzecam.com/external/v1/devices"
        )
        
        # Check that the response was returned
        self.assertEqual(response, mock_response)


if __name__ == '__main__':
    unittest.main() 