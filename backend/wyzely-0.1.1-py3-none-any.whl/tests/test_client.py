"""
Tests for the WyzeClient class
"""

import os
import unittest
from unittest.mock import patch, MagicMock

from wyzely.client import WyzeClient


class TestClient(unittest.TestCase):
    """Test cases for the WyzeClient class."""
    
    def setUp(self):
        """Set up test fixtures."""
        # Mock environment variables
        self.env_patcher = patch.dict('os.environ', {
            'KEYID': 'test_keyid',
            'APIKEY': 'test_apikey'
        })
        self.env_patcher.start()
        
        # Create a client instance
        self.client = WyzeClient()
    
    def tearDown(self):
        """Tear down test fixtures."""
        self.env_patcher.stop()
    
    def test_init_with_env_vars(self):
        """Test initialization with environment variables."""
        self.assertEqual(self.client.keyid, 'test_keyid')
        self.assertEqual(self.client.apikey, 'test_apikey')
    
    def test_init_with_params(self):
        """Test initialization with parameters."""
        client = WyzeClient(
            keyid='param_keyid',
            apikey='param_apikey'
        )
        self.assertEqual(client.keyid, 'param_keyid')
        self.assertEqual(client.apikey, 'param_apikey')
    
    def test_login(self):
        """Test login method."""
        # Mock the auth module
        self.client.auth = MagicMock()
        self.client.auth.login.return_value = {
            'access_token': 'test_access_token',
            'refresh_token': 'test_refresh_token'
        }
        
        # Call login
        response = self.client.login('test@example.com', 'password')
        
        # Verify the auth.login was called with hashed password
        self.client.auth.login.assert_called_once()
        args, _ = self.client.auth.login.call_args
        self.assertEqual(args[0], 'test@example.com')
        self.assertNotEqual(args[1], 'password')  # Password should be hashed
        
        # Verify tokens were stored
        self.assertEqual(self.client.access_token, 'test_access_token')
        self.assertEqual(self.client.refresh_token, 'test_refresh_token')
        
        # Verify response was returned
        self.assertEqual(response, {
            'access_token': 'test_access_token',
            'refresh_token': 'test_refresh_token'
        })
    
    def test_refresh_access_token(self):
        """Test refresh_access_token method."""
        # Set up initial tokens
        self.client.access_token = 'old_access_token'
        self.client.refresh_token = 'old_refresh_token'
        
        # Mock the auth module
        self.client.auth = MagicMock()
        self.client.auth.refresh.return_value = {
            'access_token': 'new_access_token',
            'refresh_token': 'new_refresh_token'
        }
        
        # Call refresh_access_token
        response = self.client.refresh_access_token()
        
        # Verify the auth.refresh was called with the old refresh token
        self.client.auth.refresh.assert_called_once_with('old_refresh_token')
        
        # Verify tokens were updated
        self.assertEqual(self.client.access_token, 'new_access_token')
        self.assertEqual(self.client.refresh_token, 'new_refresh_token')
        
        # Verify response was returned
        self.assertEqual(response, {
            'access_token': 'new_access_token',
            'refresh_token': 'new_refresh_token'
        })
    
    def test_triple_md5_hash(self):
        """Test _triple_md5_hash method."""
        # Test with a known password
        password = 'password123'
        hashed = self.client._triple_md5_hash(password)
        
        # The hash should be a 32-character hexadecimal string
        self.assertEqual(len(hashed), 32)
        self.assertTrue(all(c in '0123456789abcdef' for c in hashed))
        
        # The same password should always hash to the same value
        self.assertEqual(hashed, self.client._triple_md5_hash(password))
        
        # Different passwords should hash to different values
        self.assertNotEqual(hashed, self.client._triple_md5_hash('different'))


if __name__ == '__main__':
    unittest.main() 