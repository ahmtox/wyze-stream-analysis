import unittest
from unittest.mock import MagicMock, patch
import time
from wyzely.api.event import EventAPI


class TestEventAPI(unittest.TestCase):
    """Test cases for the EventAPI class."""

    def setUp(self):
        """Set up test fixtures."""
        self.mock_client = MagicMock()
        self.mock_client.make_api_request = MagicMock()
        self.event_api = EventAPI(self.mock_client)
        
        # Sample regular event data for testing
        self.sample_regular_event = {
            "event_id": "D03F27AEAE11131741152495",
            "device_mac": "D03F27AEAE11",
            "device_model": "HL_PAN3",
            "event_category": 0,
            "event_value": "13",
            "event_ts": 1741152495102,
            "event_resources": [
                {
                    "resource_type": "s3",
                    "type": 1,
                    "file_id": "ce7ae8493b49402e99f52d930cc3ebb4",
                    "url": "https://example.com/thumbnail.jpg",
                    "status": 2
                },
                {
                    "resource_type": "kvs",
                    "type": 2,
                    "begin_time": 1741152494810,
                    "end_time": 1741152565281,
                    "is_playable": True
                }
            ],
            "file_list": [
                {
                    "file_id": "ce7ae8493b49402e99f52d930cc3ebb4",
                    "type": 1,
                    "url": "https://example.com/thumbnail.jpg",
                    "status": 2
                }
            ],
            "tag_list": [101, 104],
            "read_state": 0
        }
        
        # Sample event with description for testing
        self.sample_description_event = {
            "event_id": "test_event_id",
            "device_mac": "test_device_mac",
            "device_model": "test_model",
            "event_start_time": 1234567890,
            "event_end_time": 1234567900,
            "vlm_insight": {
                "description_title": "Test Description",
                "video_description": "Test Details",
                "score": 0.95
            }
        }

    # Regular event API tests
    def test_get_event_list_default_params(self):
        """Test get_event_list method with default parameters."""
        # Set up the mock response
        mock_response = {
            "code": 1,
            "message": "Success",
            "data": {
                "events": [self.sample_regular_event]
            }
        }
        self.mock_client.make_api_request.return_value = mock_response
        
        # Call the method with default parameters
        result = self.event_api.get_event_list()
        
        # Verify the API request was made correctly
        self.mock_client.make_api_request.assert_called_once()
        
        # Verify the result is the same as the mock response
        self.assertEqual(result, mock_response)
    
    def test_get_events_by_device(self):
        """Test get_events_by_device method."""
        # Set up the mock response
        mock_response = {
            "code": 1,
            "message": "Success",
            "data": {
                "events": [self.sample_regular_event]
            }
        }
        self.mock_client.make_api_request.return_value = mock_response
        
        # Call the method
        device_mac = "D03F27AEAE11"
        result = self.event_api.get_events_by_device(device_mac)
        
        # Verify the API request was made correctly
        self.mock_client.make_api_request.assert_called_once()
        
        # Verify the result is the same as the mock response
        self.assertEqual(result, mock_response)
    
    def test_get_events_by_tag(self):
        """Test get_events_by_tag method."""
        # Set up the mock response
        mock_response = {
            "code": 1,
            "message": "Success",
            "data": {
                "events": [self.sample_regular_event]
            }
        }
        self.mock_client.make_api_request.return_value = mock_response
        
        # Call the method
        tag_id = 101
        result = self.event_api.get_events_by_tag(tag_id)
        
        # Verify the API request was made correctly
        self.mock_client.make_api_request.assert_called_once()
        
        # Verify the result is the same as the mock response
        self.assertEqual(result, mock_response)
    
    def test_get_thumbnail_url(self):
        """Test get_thumbnail_url method."""
        # Call the method
        url = self.event_api.get_thumbnail_url(self.sample_regular_event)
        
        # Verify the URL is extracted correctly
        self.assertEqual(url, "https://example.com/thumbnail.jpg")
        
        # Test with an event that has no thumbnail
        event_without_thumbnail = {
            "event_id": "test_id",
            "file_list": []
        }
        url = self.event_api.get_thumbnail_url(event_without_thumbnail)
        self.assertIsNone(url)
    
    def test_parse_event_data_regular_event(self):
        """Test parse_event_data method with regular events (without descriptions)."""
        parsed_event = self.event_api.parse_event_data(self.sample_regular_event)
        
        # Verify parsed data
        self.assertEqual(parsed_event["id"], "D03F27AEAE11131741152495")
        self.assertEqual(parsed_event["device"]["mac"], "D03F27AEAE11")
        self.assertEqual(parsed_event["device"]["model"], "HL_PAN3")
        self.assertEqual(parsed_event["timestamp"], 1741152495102)
        self.assertEqual(parsed_event["type"], "13")
        self.assertEqual(parsed_event["category"], 0)
        self.assertEqual(parsed_event["tags"], [101, 104])
        self.assertEqual(parsed_event["read_state"], 0)
        
        # Verify resources
        self.assertEqual(len(parsed_event["resources"]), 2)
        
        # Check thumbnail resource
        thumbnail_resource = parsed_event["resources"][0]
        self.assertEqual(thumbnail_resource["type"], "s3")
        self.assertEqual(thumbnail_resource["file_id"], "ce7ae8493b49402e99f52d930cc3ebb4")
        
        # Check video resource
        video_resource = parsed_event["resources"][1]
        self.assertEqual(video_resource["type"], "kvs")
        self.assertEqual(video_resource["begin_time"], 1741152494810)
        self.assertEqual(video_resource["end_time"], 1741152565281)
        self.assertTrue(video_resource["is_playable"])

    # Event description tests
    def test_get_event_description_with_until_time(self):
        """Test get_event_description method with a specific until_time."""
        # Set up the mock response
        mock_response = {
            "insights": [self.sample_description_event]
        }
        self.mock_client.make_api_request.return_value = mock_response
        
        # Call the method with a specific until_time
        until_time = "1234567890000"
        result = self.event_api.get_event_description(until_time)
        
        # Verify the API request was made correctly
        self.mock_client.make_api_request.assert_called_once_with(
            url="https://event-insights-v3.wyzecam.com/external/v1/events/anomaly",
            method="POST",
            json_data={"until_time": until_time}
        )
        
        # Verify the result is formatted correctly
        self.assertEqual(result["code"], 1)
        self.assertEqual(result["message"], "Success")
        self.assertEqual(result["data"]["events"], [self.sample_description_event])
    
    @patch('time.time')
    def test_get_event_description_without_until_time(self, mock_time):
        """Test get_event_description method without specifying until_time."""
        # Set up the mock time
        mock_time.return_value = 1234567.89  # This will be multiplied by 1000
        expected_time = "1234567890"
        
        # Set up the mock response
        mock_response = {
            "insights": [self.sample_description_event]
        }
        self.mock_client.make_api_request.return_value = mock_response
        
        # Call the method without until_time
        result = self.event_api.get_event_description()
        
        # Verify the API request was made correctly with the current time
        self.mock_client.make_api_request.assert_called_once_with(
            url="https://event-insights-v3.wyzecam.com/external/v1/events/anomaly",
            method="POST",
            json_data={"until_time": expected_time}
        )
        
        # Verify the result is formatted correctly
        self.assertEqual(result["code"], 1)
        self.assertEqual(result["message"], "Success")
        self.assertEqual(result["data"]["events"], [self.sample_description_event])
    
    def test_get_event_description_error_handling(self):
        """Test get_event_description method with an error."""
        # Set up the mock to raise an exception
        self.mock_client.make_api_request.side_effect = Exception("Test error")
        
        # Call the method
        result = self.event_api.get_event_description()
        
        # Verify the error is handled correctly
        self.assertEqual(result["code"], 0)
        self.assertEqual(result["message"], "Error retrieving event descriptions: Test error")
    
    def test_parse_event_data_with_description(self):
        """Test parse_event_data method with an event that has description."""
        # Call the method
        parsed_event = self.event_api.parse_event_data(self.sample_description_event)
        
        # Verify the parsed event has the expected structure and values
        self.assertEqual(parsed_event["id"], "test_event_id")
        self.assertEqual(parsed_event["device"]["mac"], "test_device_mac")
        self.assertEqual(parsed_event["device"]["model"], "test_model")
        self.assertEqual(parsed_event["timestamp"], 1234567890)
        self.assertEqual(parsed_event["end_time"], 1234567900)
        self.assertEqual(parsed_event["type"], "insight")
        self.assertEqual(parsed_event["description"], "Test Description")
        self.assertEqual(parsed_event["details"], "Test Details")
        self.assertEqual(parsed_event["score"], 0.95)
        self.assertEqual(parsed_event["read_state"], 0)
    
    def test_parse_event_data_with_missing_fields(self):
        """Test parse_event_data method with missing fields in description event."""
        # Create an event with missing fields
        incomplete_event = {
            "event_id": "test_event_id",
            "device_mac": "test_device_mac",
            "vlm_insight": {}  # Empty insight data
        }
        
        # Call the method
        parsed_event = self.event_api.parse_event_data(incomplete_event)
        
        # Verify the parsed event has default values for missing fields
        self.assertEqual(parsed_event["id"], "test_event_id")
        self.assertEqual(parsed_event["device"]["mac"], "test_device_mac")
        self.assertEqual(parsed_event["timestamp"], 0)
        self.assertEqual(parsed_event["end_time"], 0)
        self.assertEqual(parsed_event["type"], "insight")
        self.assertEqual(parsed_event["description"], "")
        self.assertEqual(parsed_event["details"], "")
        self.assertEqual(parsed_event["score"], 0)
        self.assertEqual(parsed_event["read_state"], 0)


if __name__ == '__main__':
    unittest.main() 