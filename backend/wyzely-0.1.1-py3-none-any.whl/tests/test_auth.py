"""
Tests for the Auth module
"""

import unittest
from unittest.mock import patch, MagicMock, call
import json
from wyzely.auth import Auth


class TestAuth(unittest.TestCase):
    """Test cases for the Auth class."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.mock_client = MagicMock()
        self.mock_client.app_key = 'test_app_key'
        self.mock_client.keyid = 'test_keyid'
        self.mock_client.apikey = 'test_apikey'
        self.auth = Auth(self.mock_client)
    
    @patch('requests.post')
    def test_login(self, mock_post):
        """Test login method."""
        # Mock the response
        mock_response = MagicMock()
        mock_response.json.return_value = {
            'access_token': 'test_access_token',
            'refresh_token': 'test_refresh_token'
        }
        mock_post.return_value = mock_response
        
        # Call login
        response = self.auth.login('test@example.com', 'hashed_password')
        
        # Verify the request was made correctly
        mock_post.assert_called_once()
        args, kwargs = mock_post.call_args
        self.assertEqual(args[0], 'https://auth-prod.api.wyze.com/api/user/login')
        self.assertEqual(kwargs['headers']['Content-Type'], 'application/json')
        self.assertEqual(kwargs['headers']['Keyid'], 'test_keyid')
        self.assertEqual(kwargs['headers']['Apikey'], 'test_apikey')
        
        # Verify the payload
        payload = json.loads(kwargs['data'])
        self.assertEqual(payload['email'], 'test@example.com')
        self.assertEqual(payload['password'], 'hashed_password')
        
        # Verify the response
        self.assertEqual(response, {
            'access_token': 'test_access_token',
            'refresh_token': 'test_refresh_token'
        })
    
    @patch('requests.post')
    def test_refresh(self, mock_post):
        """Test refresh method."""
        # Mock the response
        mock_response = MagicMock()
        mock_response.json.return_value = {
            'access_token': 'new_access_token',
            'refresh_token': 'new_refresh_token'
        }
        mock_post.return_value = mock_response
        
        # Call refresh
        response = self.auth.refresh('old_refresh_token')
        
        # Verify the request was made correctly
        mock_post.assert_called_once()
        args, kwargs = mock_post.call_args
        self.assertEqual(args[0], 'https://auth-prod.api.wyze.com/api/user/refresh')
        self.assertEqual(kwargs['headers']['Content-Type'], 'application/json')
        self.assertEqual(kwargs['headers']['Keyid'], 'test_keyid')
        self.assertEqual(kwargs['headers']['Apikey'], 'test_apikey')
        
        # Verify the payload
        payload = json.loads(kwargs['data'])
        self.assertEqual(payload['refresh_token'], 'old_refresh_token')
        
        # Verify the response
        self.assertEqual(response, {
            'access_token': 'new_access_token',
            'refresh_token': 'new_refresh_token'
        })


if __name__ == '__main__':
    unittest.main() 